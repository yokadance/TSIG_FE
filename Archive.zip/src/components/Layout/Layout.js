import React from "react";
import "./Layout.scss";

export default function Layout({ children }) {
  return <div>{children}</div>;
}
